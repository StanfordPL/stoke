#include "base/configuration.h"
const bool ::CVC4::Configuration::IS_GIT_BUILD = true;
const char* const ::CVC4::Configuration::GIT_BRANCH_NAME = "master";
const char* const ::CVC4::Configuration::GIT_COMMIT = "a9cfc20aecda286c3cd645d98226678f56baccc1";
const bool ::CVC4::Configuration::GIT_HAS_MODIFICATIONS = true;
