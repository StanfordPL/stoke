#include "base/configuration.h"
const bool ::CVC4::Configuration::IS_SUBVERSION_BUILD = false;
const char* const ::CVC4::Configuration::SUBVERSION_BRANCH_NAME = "unknown";
const unsigned ::CVC4::Configuration::SUBVERSION_REVISION = 0;
const bool ::CVC4::Configuration::SUBVERSION_HAS_MODIFICATIONS = false;
